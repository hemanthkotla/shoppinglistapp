//
//  ViewController.swift
//  Shoppinglistapp
//
//  Created by Student on 2019-10-16.
//  Copyright © 2019 Hemanth. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let zero = "0"
    
    var field = ""
    
    
    @IBOutlet weak var step2: UIStepper!
    @IBOutlet weak var step3: UIStepper!
    @IBOutlet weak var step7: UIStepper!
    @IBOutlet weak var step6: UIStepper!
    @IBOutlet weak var step5: UIStepper!
    @IBOutlet weak var step4: UIStepper!
    @IBOutlet weak var step1: UIStepper!
    @IBOutlet weak var text7: UITextField!
    @IBOutlet weak var text6: UITextField!
    @IBOutlet weak var text5: UITextField!
    @IBOutlet weak var text3: UITextField!
    @IBOutlet weak var text2: UITextField!
    @IBOutlet weak var text4: UITextField!
    @IBOutlet weak var text1: UITextField!
    @IBOutlet weak var label7: UILabel!
    @IBOutlet weak var label6: UILabel!
    @IBOutlet weak var label5: UILabel!
    @IBOutlet weak var label4: UILabel!
    @IBOutlet weak var label3: UILabel!
    @IBOutlet weak var label2: UILabel!
    @IBOutlet weak var label1: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }



    @IBAction func stepper1(_ sender: UIStepper) {
        label1.text = String(Int(sender.value))
        
        
      
    }
    
    @IBAction func stepper2(_ sender: UIStepper) {
        label2.text = String(Int(sender.value))
    }
    
    @IBAction func stepper3(_ sender: UIStepper) {
        label3.text = String(Int(sender.value))
    }
    
    @IBAction func stepper4(_ sender: UIStepper) {
        label4.text = String(Int(sender.value))
    }
    
    @IBAction func stepper5(_ sender: UIStepper) {
         label5.text = String(Int(sender.value))
    }

    @IBAction func stepper6(_ sender: UIStepper) {
         label6.text = String(Int(sender.value))
    }
    
    @IBAction func stepper7(_ sender: UIStepper) {
         label7.text = String(Int(sender.value))
    }
    @IBAction func clear(_ sender: UIButton) {
    
        text1.text = ""
        text2.text = ""
        text3.text = ""
        text4.text = ""
        text5.text = ""
        text6.text = ""
        text7.text = ""
        
        step1.value = 0
        step2.value = 0
        step3.value = 0
        step4.value = 0
        step5.value = 0
        step6.value = 0
        step7.value = 0
        
        label1.text = "0"
        label2.text = "0"
        label3.text = "0"
        label4.text = "0"
        label5.text = "0"
        label6.text = "0"
        label7.text = "0"
        
        }
  
    
  
}

